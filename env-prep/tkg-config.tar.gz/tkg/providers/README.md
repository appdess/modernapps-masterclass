# Providers

This directory contains the provider information including component and templates for the provider you want TKG CLI to support.

Meaning this will work as a local provider repository which will be bundles as tarball with TKG CLI.

More information on the structure of this providers directory can be found https://cluster-api.sigs.k8s.io/clusterctl/provider-contract.html
